﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //globais
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNumero2_Validated(object sender, EventArgs e)
        {
            try
            {
                errorProvider2.SetError(txtNumero2, "");
                numero2 = Convert.ToDouble(txtNumero2.Text);
            }
            catch (Exception ex)
            {
                //MessageBox.Show("número inválido" + ex.Message);
                errorProvider2.SetError(txtNumero2, "número 2 inválido");
                txtNumero2.Focus();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString("");
        }

        private void btnSub_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString("");
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString("");
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("não pode dividir por zero!!!",
                    "erro",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNumero2.Text = ""; //limpando
                txtNumero2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString("");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNumero1.Text = "";
            txtNumero2.Text = "";
            txtResultado.Text = "";
        }

        private void txtNumero1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNumero1.Text, out numero1))
            {
                //MessageBox.Show("número inválido!");
                errorProvider1.SetError(txtNumero1, "numero 1 inválido");
                txtNumero1.Focus();
            }
            else
                errorProvider1.SetError(txtNumero1, "");
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce deseja sair mesmo?",
                "saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) ==
                DialogResult.Yes)
            {
                Close();
            }
        }
        
    }
}
