﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo
{
    public partial class Form1 : Form
    {
        public double LadoA, LadoB, LadoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtboxLadoA_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtboxLadoA.Text, out LadoA)) ||
                (LadoA <= 0))
            {
                MessageBox.Show("número inválido!");
                txtboxLadoA.Text = ""; //limpando
                txtboxLadoA.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtboxLadoA.Text = "";
            txtboxLadoB.Text = "";
            txtboxLadoC.Text = "";
        }

        private void txtboxLadoB_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtboxLadoB.Text, out LadoB)) ||
                (LadoB <= 0))
            {
                MessageBox.Show("número inválido!");
                txtboxLadoB.Text = ""; //limpando
                txtboxLadoB.Focus();
            }
        }

        private void txtboxLadoC_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(txtboxLadoC.Text, out LadoC)) ||
               (LadoC <= 0))
            {
                MessageBox.Show("número inválido!");
                txtboxLadoC.Text = ""; //limpando
                txtboxLadoC.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Voce deseja sair mesmo?",
                "saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) ==
                DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnVerifcar_Click(object sender, EventArgs e)
        {
            if (LadoA > Math.Abs(LadoC - LadoB) && LadoA < LadoC + LadoB && 
                LadoB > Math.Abs(LadoA - LadoC) && LadoB < LadoA + LadoC &&
                LadoC > Math.Abs(LadoA - LadoB) && LadoC < LadoA + LadoB)
            {
                if (LadoA != LadoB && LadoA != LadoC && LadoB != LadoC)
                    MessageBox.Show("É um triângulo escaleno", "Triângulo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else if (LadoA == LadoB && LadoB == LadoC && LadoA == LadoC)
                    MessageBox.Show("É um triângulo equilátero", "Triângulo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("É um triângulo isóceles", "Triângulo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else MessageBox.Show("Não foi possivel formar um triângulo", "Falha", MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            
        }
    }
}
