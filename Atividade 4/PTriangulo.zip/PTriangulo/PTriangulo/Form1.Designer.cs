﻿namespace PTriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnVerifcar = new System.Windows.Forms.Button();
            this.txtboxLadoC = new System.Windows.Forms.TextBox();
            this.txtboxLadoB = new System.Windows.Forms.TextBox();
            this.txtboxLadoA = new System.Windows.Forms.TextBox();
            this.lblLadoC = new System.Windows.Forms.Label();
            this.lblLadoB = new System.Windows.Forms.Label();
            this.lblLadoA = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(301, 128);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(95, 48);
            this.btnSair.TabIndex = 17;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(301, 65);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(95, 48);
            this.btnLimpar.TabIndex = 16;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnVerifcar
            // 
            this.btnVerifcar.Location = new System.Drawing.Point(301, 7);
            this.btnVerifcar.Name = "btnVerifcar";
            this.btnVerifcar.Size = new System.Drawing.Size(95, 48);
            this.btnVerifcar.TabIndex = 15;
            this.btnVerifcar.Text = "Verificar";
            this.btnVerifcar.UseVisualStyleBackColor = true;
            this.btnVerifcar.Click += new System.EventHandler(this.btnVerifcar_Click);
            // 
            // txtboxLadoC
            // 
            this.txtboxLadoC.Location = new System.Drawing.Point(83, 104);
            this.txtboxLadoC.Name = "txtboxLadoC";
            this.txtboxLadoC.Size = new System.Drawing.Size(100, 20);
            this.txtboxLadoC.TabIndex = 14;
            this.txtboxLadoC.Validated += new System.EventHandler(this.txtboxLadoC_Validated);
            // 
            // txtboxLadoB
            // 
            this.txtboxLadoB.Location = new System.Drawing.Point(83, 65);
            this.txtboxLadoB.Name = "txtboxLadoB";
            this.txtboxLadoB.Size = new System.Drawing.Size(100, 20);
            this.txtboxLadoB.TabIndex = 13;
            this.txtboxLadoB.Validated += new System.EventHandler(this.txtboxLadoB_Validated);
            // 
            // txtboxLadoA
            // 
            this.txtboxLadoA.Location = new System.Drawing.Point(83, 22);
            this.txtboxLadoA.Name = "txtboxLadoA";
            this.txtboxLadoA.Size = new System.Drawing.Size(100, 20);
            this.txtboxLadoA.TabIndex = 12;
            this.txtboxLadoA.Validated += new System.EventHandler(this.txtboxLadoA_Validated);
            // 
            // lblLadoC
            // 
            this.lblLadoC.AutoSize = true;
            this.lblLadoC.Location = new System.Drawing.Point(21, 107);
            this.lblLadoC.Name = "lblLadoC";
            this.lblLadoC.Size = new System.Drawing.Size(41, 13);
            this.lblLadoC.TabIndex = 11;
            this.lblLadoC.Text = "Lado C";
            // 
            // lblLadoB
            // 
            this.lblLadoB.AutoSize = true;
            this.lblLadoB.Location = new System.Drawing.Point(21, 68);
            this.lblLadoB.Name = "lblLadoB";
            this.lblLadoB.Size = new System.Drawing.Size(41, 13);
            this.lblLadoB.TabIndex = 10;
            this.lblLadoB.Text = "Lado B";
            // 
            // lblLadoA
            // 
            this.lblLadoA.AutoSize = true;
            this.lblLadoA.Location = new System.Drawing.Point(21, 25);
            this.lblLadoA.Name = "lblLadoA";
            this.lblLadoA.Size = new System.Drawing.Size(41, 13);
            this.lblLadoA.TabIndex = 9;
            this.lblLadoA.Text = "Lado A";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(418, 191);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnVerifcar);
            this.Controls.Add(this.txtboxLadoC);
            this.Controls.Add(this.txtboxLadoB);
            this.Controls.Add(this.txtboxLadoA);
            this.Controls.Add(this.lblLadoC);
            this.Controls.Add(this.lblLadoB);
            this.Controls.Add(this.lblLadoA);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnVerifcar;
        private System.Windows.Forms.TextBox txtboxLadoC;
        private System.Windows.Forms.TextBox txtboxLadoB;
        private System.Windows.Forms.TextBox txtboxLadoA;
        private System.Windows.Forms.Label lblLadoC;
        private System.Windows.Forms.Label lblLadoB;
        private System.Windows.Forms.Label lblLadoA;
    }
}

