using Microsoft.VisualBasic;
namespace PMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExe1_Click(object sender, EventArgs e)
        {
            
            int[] vetor = new int[20];
            string aux;

            for (int i = 0; i < vetor.Length; i++)
            {
                aux = Interaction.InputBox("Insira Numero","Numero");

                if (!int.TryParse(aux, out vetor[i])){
                    MessageBox.Show("Valor Inv�lido");
                    i--;
                }
            }

            aux = "";
        }
    }
}
