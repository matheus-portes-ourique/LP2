﻿namespace PMatrizes
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnVerificar = new Button();
            lboxGabarito = new ListBox();
            SuspendLayout();
            // 
            // btnVerificar
            // 
            btnVerificar.Location = new Point(26, 110);
            btnVerificar.Name = "btnVerificar";
            btnVerificar.Size = new Size(176, 176);
            btnVerificar.TabIndex = 0;
            btnVerificar.Text = "Verificar";
            btnVerificar.UseVisualStyleBackColor = true;
            btnVerificar.Click += btnVerificar_Click;
            // 
            // lboxGabarito
            // 
            lboxGabarito.FormattingEnabled = true;
            lboxGabarito.ItemHeight = 15;
            lboxGabarito.Location = new Point(241, 12);
            lboxGabarito.Name = "lboxGabarito";
            lboxGabarito.Size = new Size(327, 349);
            lboxGabarito.TabIndex = 1;
            // 
            // frmExercicio4
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(580, 406);
            Controls.Add(lboxGabarito);
            Controls.Add(btnVerificar);
            Name = "frmExercicio4";
            Text = "frmExercicio4";
            ResumeLayout(false);
        }

        #endregion

        private Button btnVerificar;
        private ListBox lboxGabarito;
    }
}