﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExe1 = new Button();
            btnExe2 = new Button();
            btnExe3 = new Button();
            btnExe4 = new Button();
            btnExe5 = new Button();
            SuspendLayout();
            // 
            // btnExe1
            // 
            btnExe1.Location = new Point(12, 72);
            btnExe1.Name = "btnExe1";
            btnExe1.Size = new Size(175, 81);
            btnExe1.TabIndex = 0;
            btnExe1.Text = "Exercício 1";
            btnExe1.UseVisualStyleBackColor = true;
            btnExe1.Click += btnExe1_Click;
            // 
            // btnExe2
            // 
            btnExe2.Location = new Point(193, 72);
            btnExe2.Name = "btnExe2";
            btnExe2.Size = new Size(175, 81);
            btnExe2.TabIndex = 1;
            btnExe2.Text = "Exercício 2";
            btnExe2.UseVisualStyleBackColor = true;
            // 
            // btnExe3
            // 
            btnExe3.Location = new Point(374, 72);
            btnExe3.Name = "btnExe3";
            btnExe3.Size = new Size(175, 81);
            btnExe3.TabIndex = 2;
            btnExe3.Text = "Exercício 3";
            btnExe3.UseVisualStyleBackColor = true;
            // 
            // btnExe4
            // 
            btnExe4.Location = new Point(555, 72);
            btnExe4.Name = "btnExe4";
            btnExe4.Size = new Size(175, 81);
            btnExe4.TabIndex = 3;
            btnExe4.Text = "Exercício 4";
            btnExe4.UseVisualStyleBackColor = true;
            // 
            // btnExe5
            // 
            btnExe5.Location = new Point(736, 72);
            btnExe5.Name = "btnExe5";
            btnExe5.Size = new Size(175, 81);
            btnExe5.TabIndex = 4;
            btnExe5.Text = "Exercício 5";
            btnExe5.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(920, 206);
            Controls.Add(btnExe5);
            Controls.Add(btnExe4);
            Controls.Add(btnExe3);
            Controls.Add(btnExe2);
            Controls.Add(btnExe1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnExe1;
        private Button btnExe2;
        private Button btnExe3;
        private Button btnExe4;
        private Button btnExe5;
    }
}
