﻿namespace PMatrizes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExe1 = new Button();
            btnExe2 = new Button();
            btnExe3 = new Button();
            btnExe4 = new Button();
            btnExe5 = new Button();
            SuspendLayout();
            // 
            // btnExe1
            // 
            btnExe1.Location = new Point(8, 43);
            btnExe1.Margin = new Padding(2);
            btnExe1.Name = "btnExe1";
            btnExe1.Size = new Size(122, 49);
            btnExe1.TabIndex = 0;
            btnExe1.Text = "Exercício 1";
            btnExe1.UseVisualStyleBackColor = true;
            btnExe1.Click += btnExe1_Click;
            // 
            // btnExe2
            // 
            btnExe2.Location = new Point(135, 43);
            btnExe2.Margin = new Padding(2);
            btnExe2.Name = "btnExe2";
            btnExe2.Size = new Size(122, 49);
            btnExe2.TabIndex = 1;
            btnExe2.Text = "Exercício 2";
            btnExe2.UseVisualStyleBackColor = true;
            btnExe2.Click += btnExe2_Click_1;
            // 
            // btnExe3
            // 
            btnExe3.Location = new Point(262, 43);
            btnExe3.Margin = new Padding(2);
            btnExe3.Name = "btnExe3";
            btnExe3.Size = new Size(122, 49);
            btnExe3.TabIndex = 2;
            btnExe3.Text = "Exercício 3";
            btnExe3.UseVisualStyleBackColor = true;
            btnExe3.Click += btnExe3_Click_1;
            // 
            // btnExe4
            // 
            btnExe4.Location = new Point(514, 43);
            btnExe4.Margin = new Padding(2);
            btnExe4.Name = "btnExe4";
            btnExe4.Size = new Size(122, 49);
            btnExe4.TabIndex = 3;
            btnExe4.Text = "Exercício 5";
            btnExe4.UseVisualStyleBackColor = true;
            btnExe4.Click += btnExe4_Click;
            // 
            // btnExe5
            // 
            btnExe5.Location = new Point(388, 43);
            btnExe5.Margin = new Padding(2);
            btnExe5.Name = "btnExe5";
            btnExe5.Size = new Size(122, 49);
            btnExe5.TabIndex = 4;
            btnExe5.Text = "Exercício 4";
            btnExe5.UseVisualStyleBackColor = true;
            btnExe5.Click += btnExe5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(644, 124);
            Controls.Add(btnExe5);
            Controls.Add(btnExe4);
            Controls.Add(btnExe3);
            Controls.Add(btnExe2);
            Controls.Add(btnExe1);
            Margin = new Padding(2);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Button btnExe1;
        private Button btnExe2;
        private Button btnExe3;
        private Button btnExe4;
        private Button btnExe5;
    }
}
