﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PMatrizes
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            string[,] resp = new string[6, 10];
            string[] gabarito = { "A", "B", "C", "D", "E", "A", "B", "C", "D", "E" };

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    string entrada;

                    do
                    {
                        entrada = Interaction.InputBox($"Digite sua resposta (A, B, C, D ou E), Aluno {i + 1} e questão {j + 1}", "Entrada de dados");

                    } while (entrada != "A" && entrada != "B" && entrada != "C" && entrada != "D" && entrada != "E");

                    resp[i, j] = entrada;
                }
            }

            for (int i = 0; i < 6; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (string.Compare(resp[i, j], gabarito[i]) == 0)
                    {
                        lboxGabarito.Items.Add($"O aluno: {i + 1} acertou questão: {j + 1} era {gabarito[j]} escolheu {resp[i, j]}");
                    }
                    else
                    {
                        lboxGabarito.Items.Add($"O aluno: {i + 1} errou questão: {j + 1} era {gabarito[j]} escolheu {resp[i, j]}");
                    }
                }
            }
        }
    }
}
