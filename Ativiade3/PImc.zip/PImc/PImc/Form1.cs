﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PImc
{
    public partial class Form1 : Form
    {
       public double Peso, Altura, IMC;

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(mskbxAltura.Text, out Altura)) ||
                (Altura <= 0))
            {
                MessageBox.Show("número inválido!");
                mskbxAltura.Text = ""; //limpando
                mskbxAltura.Focus();
            }

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = Peso/(Math.Pow(Altura,2));
            IMC = Math.Round(IMC, 1);
            txtImc.Text = IMC.ToString();

            if (IMC > 40)
                MessageBox.Show("Você está com Obesiade Grave!", "IMC", MessageBoxButtons.OK);
            else if (IMC >= 30)
                MessageBox.Show("Você está com Obesiade!", "IMC", MessageBoxButtons.OK);
            else if (IMC >= 25)
                MessageBox.Show("Você está com sobrepeso", "IMC", MessageBoxButtons.OK);
            else if (IMC >=18.5)
                MessageBox.Show("Você está normal!", "IMC", MessageBoxButtons.OK);
            else
                MessageBox.Show("Você está abaixo do peso!", "IMC", MessageBoxButtons.OK);
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Text = "";
            mskbxPeso.Text = "";
            txtImc.Text = "";
        }

        private void txtImc_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Voce deseja sair mesmo?",
                "saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) ==
                DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if ((!Double.TryParse(mskbxPeso.Text, out Peso)) ||
                (Peso <= 0))
            {
                MessageBox.Show("número inválido!");
                mskbxPeso.Text = ""; //limpando
                mskbxPeso.Focus();
            }
        }
    }
}
